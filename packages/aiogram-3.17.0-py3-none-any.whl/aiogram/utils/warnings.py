class AiogramWarning(Warning):
    pass


class Recommendation(AiogramWarning):
    pass
