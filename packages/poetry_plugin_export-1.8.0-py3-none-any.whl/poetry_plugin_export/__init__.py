from __future__ import annotations

from poetry.utils._compat import metadata


__version__ = metadata.version("poetry-plugin-export")  # type: ignore[no-untyped-call]
