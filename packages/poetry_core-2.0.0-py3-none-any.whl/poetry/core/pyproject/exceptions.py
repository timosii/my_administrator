from __future__ import annotations

from poetry.core.exceptions import PoetryCoreError


class PyProjectError(PoetryCoreError):
    pass
